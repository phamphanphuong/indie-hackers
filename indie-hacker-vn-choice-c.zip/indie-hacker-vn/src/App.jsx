import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";

import Home from "./pages/Home";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Videos from "./pages/Videos";
import VN30Bot from "./pages/VN30Bot";
import Projects from "./pages/Projects";
import About from "./pages/About";

export default function App(){
  return (
    <BrowserRouter basename="/indie-hacker-vn">
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/videos" element={<Videos />} />
          <Route path="/vn30-bot" element={<VN30Bot />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}