import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { marked } from "marked";

export default function BlogPost(){
  const { slug } = useParams();
  const [html,setHtml]=useState("");

  useEffect(()=>{
    fetch("/indie-hacker-vn/blog/" + slug + ".md")
      .then(function(r){return r.text();})
      .then(function(t){setHtml(marked(t));});
  },[slug]);

  return <article className="prose dark:prose-invert mt-6" dangerouslySetInnerHTML={{__html:html}} />;
}